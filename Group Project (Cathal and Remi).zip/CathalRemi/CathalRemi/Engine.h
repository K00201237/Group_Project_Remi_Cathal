#pragma once
#include <SFML/Graphics.hpp>


using namespace sf;

class Engine
{
private:

    Clock clock;

	enum class State { Menu, Playing, Shop, GameOver };

	Vector2f resolution;

	RenderWindow window;


    //  view to center Player
    sf::View playerView;
    // Set HUD View
    sf::View HUDView;
    // Set Background View
    sf::View BackgroundView;
    

    // Player 
    sf::Texture playerTexture;
    sf::Sprite playerSprite;

    // Enemy 
    sf::Texture enemyTexture;
    sf::Sprite enemySprite;



    // Background
    sf::Texture backgroundTexture;
    sf::Sprite backgroundSprite;

    // Menu
    sf::Texture m_BigMenuTexture;
    sf::Sprite m_BigMenuSprite;

    // Shop
    sf::Texture shopMenuTexture;
    sf::Sprite shopMenuSprite;

    // Health bar
    RectangleShape healthBar;
    
    //Gravity Variables:
    float playerSpeed;
    float jumpSpeed;
    float gravity;
    float groundHeight;
    

    void draw();
  

public:

   
    Engine();
    void runGame();

};