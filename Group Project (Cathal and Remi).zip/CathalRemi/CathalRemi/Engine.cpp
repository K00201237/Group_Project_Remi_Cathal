#include "stdafx.h"
#include <SFML/Graphics.hpp>
#include "Engine.h"
#include "Player.h"
#include "Enemy.h"
#include "AudioManager.h"
#include <string>
#include <iostream>

Engine::Engine()
{
	Player player;
	
	// Window
	resolution.x = VideoMode::getDesktopMode().width;
	resolution.y = VideoMode::getDesktopMode().height;

	window.create(VideoMode(resolution.x, resolution.y),
		"Code Week Test Project",
		Style::Fullscreen);

	window.setVerticalSyncEnabled(true);


	//  view to center Player
	playerView.setSize(resolution);
	// Set HUD View
	sf::View HUDView(sf::Vector2f(1250, 700), sf::Vector2f(resolution.x, resolution.y));
	// Set Background View
	BackgroundView.setSize(resolution);


	// Player
	if (!playerTexture.loadFromFile("graphics/player_idle.png"))
	{
		std::cout << "Could not load player texture";
	}
	playerTexture.setSmooth(true);

	playerSprite.setTexture(playerTexture);
	//playerSprite.setPosition(sf::Vector2f(500,500));
	playerSprite.setPosition(0, 1100);

	// Enemy
	if (!enemyTexture.loadFromFile("graphics/enemy.png"))
	{
		std::cout << "Could not load player texture";
	}
	enemyTexture.setSmooth(true);

	enemySprite.setTexture(enemyTexture);
	//playerSprite.setPosition(sf::Vector2f(500,500));
	enemySprite.setPosition(1200, 1100);

	//Background
	if (!backgroundTexture.loadFromFile("graphics/countryBackgrnd.png"))
	{
		std::cout << "Could not load background texture";
		
	}
	backgroundTexture.setSmooth(true);

	backgroundSprite.setTexture(backgroundTexture);
	backgroundSprite.setPosition(sf::Vector2f(0, 0));
	backgroundSprite.setScale(resolution.x / backgroundSprite.getLocalBounds().width, resolution.y / backgroundSprite.getLocalBounds().height);

	// Menu
	if (!m_BigMenuTexture.loadFromFile("graphics/MtFuji3.9.png"))
	{
		std::cout << "Could not load menu texture";
		
	}
	m_BigMenuTexture.setSmooth(true);

	m_BigMenuSprite.setTexture(m_BigMenuTexture);
	m_BigMenuSprite.setPosition(sf::Vector2f(0, 0));
	//m_BigMenuSprite.setScale(resolution.x / m_BigMenuSprite.getLocalBounds().width, resolution.y / m_BigMenuSprite.getLocalBounds().height);

	// Shop
	if (!shopMenuTexture.loadFromFile("graphics/shop.png"))
	{
		std::cout << "Could not load shop texture";

	}
	backgroundTexture.setSmooth(true);

	shopMenuSprite.setTexture(shopMenuTexture);
	shopMenuSprite.setPosition(sf::Vector2f(0, 0));
	shopMenuSprite.setScale(resolution.x / shopMenuSprite.getLocalBounds().width, resolution.y / shopMenuSprite.getLocalBounds().height);

	// Health bar
	healthBar.setFillColor(Color::Red);
	healthBar.setPosition(0, 0);
	// size up the health bar

	healthBar.setSize(Vector2f(player.getHealth() * 3, 70));

	
	

}

void Engine::runGame()
{
	while (window.isOpen())
	{
		draw();
	}
}
