#pragma once
#include <SFML/Graphics.hpp>

using namespace sf;

class Player
{
private:


	// How much health does the player have
	int p_health;

	// The players Maximum health value
	int p_maxHealth;

	// When was the player last hit
	Time m_LastHit;



public:

	Player();

	bool Player::hit(Time timeHit);

	

	//How much health has the player currently got
	int getHealth();

;

protected:
	int Start_Health;

	
};