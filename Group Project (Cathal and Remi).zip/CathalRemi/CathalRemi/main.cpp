#include "stdafx.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "Player.h"
#include "Engine.h"

using namespace sf;

int main()
{

	Engine engine;

	engine.runGame();

	return 0;

  
}