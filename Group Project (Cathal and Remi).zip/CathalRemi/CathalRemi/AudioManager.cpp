#include "stdafx.h"
#include "AudioManager.h"

AudioManager::AudioManager()
{
	menuBuffer.loadFromFile("sounds/menuMusic.wav");
	jumpBuffer.loadFromFile("sounds/jump.wav");
}

void AudioManager::playMenuMusic()
{
	menuSound.play();
}

void AudioManager::playJumpSound()
{
	jumpSound.play();
}
