#pragma once
#include <SFML/Audio.hpp>
using namespace sf;

class AudioManager
{

private:

	// Buffers
	SoundBuffer menuBuffer;
	SoundBuffer jumpBuffer;


	// Sounds

	Sound menuSound;
	Sound jumpSound;

public:

	AudioManager();
	void playMenuMusic();
	void playJumpSound();
};