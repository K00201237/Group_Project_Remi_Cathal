#pragma once
#include "SFML/Graphics.hpp"

using namespace sf;

class Enemy
{
private:

    // Enemy 
    int enemyHealth;

public:
    
   Enemy();

   int getEnemyHealth();

protected:

    int enemyStartHealth = 40;

};