#include "stdafx.h"
#include "Enemy.h"

Enemy::Enemy()
{
}

int Enemy::getEnemyHealth()
{
	return enemyStartHealth;
}


