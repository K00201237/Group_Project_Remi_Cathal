#include "stdafx.h"
#include <SFML/Graphics.hpp>
#include "Engine.h"
#include "Player.h"
#include "AudioManager.h"
#include <iostream>

void Engine::draw()
{
    State state = State::Menu;

    Player player;
    Time gameTimeTotal;

    AudioManager audio;

    // Gravity
    float playerSpeed = 8.0f;
    float enemySpeed = 8.0f;
    float jumpSpeed = 10.0f;
    float gravity = 1;
    float groundHeight = 1200;
    sf:Vector2f velocity(sf::Vector2f(0, 0));



    // run the program as long as the window is open
    while (window.isOpen())
    {


        // check all the window's events that were triggered since the last iteration of the loop
        sf::Event event;
        while (window.pollEvent(event))
        {


            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
            {
                window.close();
            }

           
            if (event.type == Event::KeyPressed)

                //Exit from menu
                if (event.key.code == Keyboard::Num3 && state == State::Menu)
                {

                    window.close();
                    //m_Window.clear(Color::White);
                    //state = State::Playing;
                    //reset the clock so there is no frame jump
                    //clock.restart();
                }
                //enter playing sate from menu
                else if (event.key.code == Keyboard::Num1 && state == State::Menu)
                {
                    window.clear(Color::White);
                    state = State::Playing;
                    //reset the clock so there is no frame jump
                    clock.restart();
                }
            //enter shop sate from menu
                else if (event.key.code == Keyboard::Num2 && state == State::Menu)
                {
                    window.clear(Color::White);
                    state = State::Shop;
                    //reset the clock so there is no frame jump
                    clock.restart();
                }
            // Return to menu
            if (event.key.code == Keyboard::Return && state == State::Playing)
            {
                window.clear(Color::White);
                clock.restart();
                state = State::Menu;
            }
            else if (event.key.code == Keyboard::Return && state == State::Shop)
            {
                window.clear(Color::White);
                clock.restart();
                state = State::Menu;
            }

            else if (event.key.code == Keyboard::Return && state == State::GameOver)
            {
                window.clear(Color::White);
                clock.restart();
                state = State::Menu;
            }

            

            // Close window with ESC key
            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Escape)
                {
                    window.close();
                }
            }


            // Gravity

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            {
                velocity.x = playerSpeed;
            }
            else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
            {
                velocity.x = -playerSpeed;
            }

            else
            {
                velocity.x = 0;
            }

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
            {
                audio.playJumpSound();
                velocity.y = -jumpSpeed;

            }

            playerSprite.move(velocity.x, velocity.y);

            if (playerSprite.getPosition().y + playerSprite.getGlobalBounds().height < groundHeight || velocity.y < 0)
            {
                velocity.y += gravity;
            }
            else
            {
                playerSprite.setPosition(playerSprite.getPosition().x, groundHeight - playerSprite.getGlobalBounds().height);
                velocity.y = 0;
            }


            if (event.type == sf::Event::KeyReleased)
            {
                if (event.key.code == sf::Keyboard::Up)
                {
                    velocity.y = gravity;
                }
            }

            // Collsion

            if (playerSprite.getGlobalBounds().intersects(enemySprite.getGlobalBounds()))
            {
                player.hit(gameTimeTotal);
                
            }

            
            
            

            // clear the window 
            window.clear();

            /*
               Draw Below

            */
            
            if (state == State::Menu)
            {
                audio.playMenuMusic();
                // Switch to background view
                window.setView(BackgroundView);
                // Draw the background
                window.draw(m_BigMenuSprite);
                window.setMouseCursorVisible(false);
                //m_BigMenuSprite.setPosition(0, 0);

                // Load the font
                Font font;
                font.loadFromFile("fonts/invasion.ttf");

                //Print text options to screen
                Text menuText1;
                menuText1.setFont(font);
                menuText1.setString("1.For Game \n");
                menuText1.setCharacterSize(48);
                menuText1.setColor(sf::Color(255, 255, 255));
                menuText1.setPosition(70.0, 500.0);

                Text menuText2;
                menuText2.setFont(font);
                menuText2.setString("2.For Shop\n");
                menuText2.setCharacterSize(48);
                menuText2.setColor(sf::Color(255, 255, 255));
                menuText2.setPosition(70.0, 600.0);

                Text menuExitText4;
                menuExitText4.setFont(font);
                menuExitText4.setString("3.To Exit game\n");
                menuExitText4.setCharacterSize(48);
                menuExitText4.setColor(sf::Color(255, 255, 255));
                menuExitText4.setPosition(70.0, 700.0);

                window.draw(menuText1);
                window.draw(menuText2);
                // m_Window.draw(menuText3);
                window.draw(menuExitText4);

                window.setView(playerView);
            }


            if (state == State::Playing)
            {
                audio.playMenuMusic();
                playerView.setCenter(playerSprite.getPosition());
                window.setView(playerView);
                window.draw(backgroundSprite);
                window.setMouseCursorVisible(false);

                // HUDView.setCenter(playerSprite.getPosition());

                 // draw the sprite
              //  playerSprite.setPosition(x, y);
                window.draw(enemySprite);
                window.draw(playerSprite);
                

                window.setView(HUDView);
                window.draw(healthBar);

            }

            if (state == State::Shop)
            {
                audio.playMenuMusic();
                window.setMouseCursorVisible(false);
                // Switch to background view
                window.setView(BackgroundView);
                // Draw the background
                //m_Window.draw(m_BackgroundSprite);
                window.draw(shopMenuSprite);

                // Load the font
                Font font;
                font.loadFromFile("fonts/invasion.ttf");

                //Print text options to screen
                Text shopStartText;
                shopStartText.setFont(font);
                shopStartText.setString("SHOP\n");
                shopStartText.setCharacterSize(48);
                shopStartText.setColor(sf::Color(255, 255, 255));
                shopStartText.setPosition(450.0, 100.0);

                Text shopText1;
                shopText1.setFont(font);
                shopText1.setString("1.For Wakizashi \n");//short sword, makes with katana pair of swords called daisho
                shopText1.setCharacterSize(48);
                shopText1.setColor(sf::Color(255, 255, 255));
                shopText1.setPosition(70.0, 300.0);

                Text shopText2;
                shopText2.setFont(font);
                shopText2.setString("2.For Katana\n");
                shopText2.setCharacterSize(48);
                shopText2.setColor(sf::Color(255, 255, 255));
                shopText2.setPosition(70.0, 400.0);

                Text shopText3;
                shopText3.setFont(font);
                shopText3.setString("3.For Nodachi\n");//long battlefield sword
                shopText3.setCharacterSize(48);
                shopText3.setColor(sf::Color(255, 255, 255));
                shopText3.setPosition(70.0, 500.0);

                Text shopText4;
                shopText4.setFont(font);
                shopText4.setString("4.For Arcanum\n");
                shopText4.setCharacterSize(48);
                shopText4.setColor(sf::Color(255, 255, 255));
                shopText4.setPosition(70.0, 600.0);

                Text shopExitText;
                shopExitText.setFont(font);
                shopExitText.setString("Hit Enter To Menu\n");
                shopExitText.setCharacterSize(48);
                shopExitText.setColor(sf::Color(255, 255, 255));
                shopExitText.setPosition(270.0, 900.0);

                window.draw(shopStartText);
                window.draw(shopText1);
                window.draw(shopText2);
                window.draw(shopText3);
                window.draw(shopText4);
                window.draw(shopExitText);



            }


            /*
               Draw Above
            */



            // end the current frame
            window.display();


        }
    }



    
}
