#include "stdafx.h"
#include "Player.h"
#include <SFML/Graphics.hpp>


using namespace sf;

Player::Player()
{
	Start_Health = 100;
	p_health = Start_Health;
	p_maxHealth = Start_Health;

}

bool Player::hit(Time timeHit)
{
	if (timeHit.asMilliseconds() - m_LastHit.asMilliseconds() > 300)     // 3 tenths of second
	{
		m_LastHit = timeHit;
		p_health -= 10;
		return true;
	}
	else
	{
		return false;
	}
}



int Player::getHealth()
{
	return p_health;
}


